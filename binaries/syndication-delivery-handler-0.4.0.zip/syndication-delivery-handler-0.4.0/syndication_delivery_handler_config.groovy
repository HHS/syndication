publish.url = 'http://localhost:8080/Syndication/api/v2/resources/media/htmls.json'
server.base.url = 'http://localhost:9992'

http.connection.timeout = 90
http.socket.timeout = 90

api.key.name = 'syndication_api_key'
api.key.header = 'Authorization'
